## V 0.3 (24 January 2018)
  * Improved handling of forecastfunction argument in thief()
  * Bug fixes
  * pkgdown documentation

## V 0.2 (7 September 2016)
  * First version on CRAN

## V 0.1 (22 August 2016)
  * First version on github
